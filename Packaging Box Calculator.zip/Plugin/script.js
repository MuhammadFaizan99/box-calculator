// Object containing image URLs for each Product Name
const productImages = {
  mailer: "./Images/mailer.png",
  folding: "./Images/folding.jpg",
  rigid: "./Images/rigid.webp",
  magnetic: "./Images/magnetic.png",
  display: "./Images/display.jpg",
  tray_sleeve: "./Images/tray_sleeve.png",
  cardboard_tubes: "./Images/cardboard_tubes.jpg",
  foldable_lid_base: "./Images/foldable_lid_base.webp",
  cake: "./Images/cake.jpg",
  paper: "./Images/paper.jpg",
  pillow: "./Images/pillow.jpg",
  shipping: "./Images/shipping.jpg",
  rectangle: "./Images/Rectangle.webp",
  pizza: "./Images/Pizza Type.jpg",
  tuck_in: "./Images/tuck_in.webp",
};

// Object containing image URLs for each Paper Quality/Card Quality
const paperQualityImages = {
  kraft: "./Images/kraft.jpg",
  white: "./Images/white.webp",
  corrugated: "./Images/corrugated.jpg",
  coated: "./Images/coated.jpg",
  fbb: "./Images/fbb.webp",
};

// Function to display selected images
function displaySelectedImages() {
  const productName = document.getElementById("productName").value;
  const paperQuality = document.getElementById("paperQuality").value;
  const productImage = productImages[productName];
  const paperQualityImage = paperQualityImages[paperQuality];
  const productImageContainer = document.getElementById(
    "productImageContainer"
  );
  const paperQualityImageContainer = document.getElementById(
    "paperQualityImageContainer"
  );

  // Clear previous images
  productImageContainer.innerHTML = "";
  paperQualityImageContainer.innerHTML = "";

  // Insert Product Name image
  if (productImage) {
    const productImg = document.createElement("img");
    productImg.src = productImage;
    productImg.alt = productName;
    productImageContainer.appendChild(productImg);
    productImg.classList.add("fade-in"); // Add fade-in class
  }

  // Insert Paper Quality image
  if (paperQualityImage) {
    const paperQualityImg = document.createElement("img");
    paperQualityImg.src = paperQualityImage;
    paperQualityImg.alt = paperQuality;
    paperQualityImageContainer.appendChild(paperQualityImg);
    paperQualityImg.classList.add("fade-in"); // Add fade-in class
  }
}

// Function to calculate the price and display the result
function calculatePrice() {
  const productName = document.getElementById("productName").value;
  const paperQuality = document.getElementById("paperQuality").value;
  const length = parseFloat(document.getElementById("length").value);
  const width = parseFloat(document.getElementById("width").value);
  const height = parseFloat(document.getElementById("height").value);
  let sizeUnit;
  const unitInches = document.getElementById("unitInches");
  const unitMm = document.getElementById("unitMm");
  const unitCm = document.getElementById("unitCm");

  if (unitInches.classList.contains("active")) {
    sizeUnit = "inches";
  } else if (unitMm.classList.contains("active")) {
    sizeUnit = "mm";
  } else if (unitCm.classList.contains("active")) {
    sizeUnit = "cm";
  }

  const color = document.getElementById("color").value;
  const print = document.getElementById("print").value;
  const coating = document.getElementById("coating").value;
  const quantity = parseInt(document.getElementById("quantity").value);

  // Validation
  const errorMessages = [];
  if (!productName) errorMessages.push("Product Name");
  if (!paperQuality) errorMessages.push("Paper Quality");
  if (isNaN(length)) errorMessages.push("Length");
  if (isNaN(width)) errorMessages.push("Width");
  if (isNaN(height)) errorMessages.push("Height");
  if (!color) errorMessages.push("Color");
  if (!print) errorMessages.push("Print");
  if (!coating) errorMessages.push("Coating");
  if (!quantity) errorMessages.push("Quantity");

  if (errorMessages.length > 0) {
    const errorMessage =
      "Please fill in the following fields: " + errorMessages.join(", ");
    document.getElementById(
      "result"
    ).innerHTML = `<span style="color: red;">${errorMessage}</span>`;
    return; // Exit function if there are validation errors
  }

  let size;
  switch (sizeUnit) {
    case "mm":
      size = {
        length: length / 25.4,
        width: width / 25.4,
        height: height / 25.4,
      };
      break;
    case "cm":
      size = {
        length: length / 2.54,
        width: width / 2.54,
        height: height / 2.54,
      };
      break;
    default:
      size = { length, width, height };
      break;
  }

  const areaOfBox =
    2 *
    (size.length * size.width +
      size.length * size.height +
      size.width * size.height);
  const productBase = getProductBase(productName);
  const paperQualityBase = getPaperQualityBase(paperQuality);
  const colorBase = getColorBase(color);
  const printBase = getPrintBase(print);
  const coatingBase = getCoatingBase(coating);

  const price =
    quantity *
    (areaOfBox * productBase +
      areaOfBox * paperQualityBase +
      areaOfBox * colorBase +
      areaOfBox * printBase +
      areaOfBox * coatingBase);

  const resultElement = document.getElementById("result");
  resultElement.innerHTML = `Price/Box: PKR ${(
    price.toFixed(2) / quantity
  ).toFixed(2)}<br>Total Price of Box: PKR ${price.toFixed(2)}`;

  // Triggering fade-in effect
  resultElement.classList.add("show");
}

function getProductBase(productName) {
  switch (productName) {
    case "mailer":
      return 0.15;
    case "folding":
      return 0.15;
    case "rigid":
      return 0.2;
    case "magnetic":
      return 0.35;
    case "display":
      return 0.22;
    case "tray_sleeve":
      return 0.25;
    case "cardboard_tubes":
      return 0.15;
    case "foldable_lid_base":
      return 0.2;
    case "cake":
      return 0.03;
    case "paper":
      return 0.000005;
    case "pillow":
      return 0.3;
    case "shipping":
      return 0.2;
    case "rectangle":
      return 0.16;
    case "pizza":
      return 0.15;
    case "tuck_in":
      return 0.16;
    default:
      return 0;
  }
}

function getPaperQualityBase(paperQuality) {
  switch (paperQuality) {
    case "kraft":
      return 0.06;
    case "white":
      return 0.05;
    case "corrugated":
      return 0.05;
    case "coated":
      return 0.04;
    case "fbb":
      return 0.04;
    default:
      return 0;
  }
}

function getColorBase(color) {
  switch (color) {
    case "brown":
      return 0.04;
    case "white":
      return 0.06;
    default:
      return 0;
  }
}

function getPrintBase(print) {
  switch (print) {
    case "none":
      return 0.0;
    case "single":
      return 0.03;
    case "multi":
      return 0.06;
    default:
      return 0;
  }
}

function getCoatingBase(coating) {
  switch (coating) {
    case "thermalGloss":
      return 0.05;
    case "pvcLamination":
      return 0.05;
    case "emboss":
      return 0.06;
    case "silver":
      return 0.05;
    case "leafFull":
      return 0.08;
    case "hybridDripoff":
      return 0.04;
    case "varnishCoating":
      return 0.05;
    case "thermalMATT":
      return 0.05;
    case "spotUV":
      return 0.05;
    case "mattHalf":
      return 0.04;
    case "halfGlossLamination":
      return 0.06;
    case "mattLamination":
      return 0.05;
    case "glossLamination":
      return 0.06;
    case "leaf":
      return 0.06;
    case "none":
      return 0;
    default:
      return 0;
  }
}

// Function to change the unit of size input fields
function changeUnit(unit) {
  const lengthInput = document.getElementById("length");
  const widthInput = document.getElementById("width");
  const heightInput = document.getElementById("height");

  let lengthValue = parseFloat(lengthInput.value);
  let widthValue = parseFloat(widthInput.value);
  let heightValue = parseFloat(heightInput.value);

  switch (unit) {
    case "inches":
      // Convert to inches if currently in mm or cm
      if (document.getElementById("unitMm").classList.contains("active")) {
        lengthValue /= 25.4;
        widthValue /= 25.4;
        heightValue /= 25.4;
      } else if (document.getElementById("unitCm").classList.contains("active")) {
        lengthValue /= 2.54;
        widthValue /= 2.54;
        heightValue /= 2.54;
      }
      break;
    case "mm":
      // Convert to mm if currently in inches or cm
      if (document.getElementById("unitInches").classList.contains("active")) {
        lengthValue *= 25.4;
        widthValue *= 25.4;
        heightValue *= 25.4;
      } else if (document.getElementById("unitCm").classList.contains("active")) {
        lengthValue *= 10;
        widthValue *= 10;
        heightValue *= 10;
      }
      break;
    case "cm":
      // Convert to cm if currently in inches or mm
      if (document.getElementById("unitInches").classList.contains("active")) {
        lengthValue *= 2.54;
        widthValue *= 2.54;
        heightValue *= 2.54;
      } else if (document.getElementById("unitMm").classList.contains("active")) {
        lengthValue /= 10;
        widthValue /= 10;
        heightValue /= 10;
      }
      break;
  }

  // Update input values
  lengthInput.value = lengthValue.toFixed(2);
  widthInput.value = widthValue.toFixed(2);
  heightInput.value = heightValue.toFixed(2);

  // Update placeholders
  switch (unit) {
    case "inches":
      lengthInput.placeholder = "Enter Length in inches";
      widthInput.placeholder = "Enter Width in inches";
      heightInput.placeholder = "Enter Height in inches";
      break;
    case "mm":
      lengthInput.placeholder = "Enter Length in mm";
      widthInput.placeholder = "Enter Width in mm";
      heightInput.placeholder = "Enter Height in mm";
      break;
    case "cm":
      lengthInput.placeholder = "Enter Length in cm";
      widthInput.placeholder = "Enter Width in cm";
      heightInput.placeholder = "Enter Height in cm";
      break;
  }

  // Update active class
  document.getElementById("unitInches").classList.remove("active");
  document.getElementById("unitMm").classList.remove("active");
  document.getElementById("unitCm").classList.remove("active");
  document.getElementById(`unit${unit.charAt(0).toUpperCase() + unit.slice(1)}`).classList.add("active");
}

window.addEventListener("DOMContentLoaded", (event) => {
  // Set default values for input fields
  document.getElementById("unitInches").classList.add("active");
  document.getElementById("unitMm").classList.remove("active");
  document.getElementById("unitCm").classList.remove("active");
  document.getElementById("productName").value = "mailer";
  document.getElementById("paperQuality").value = "kraft";
  document.getElementById("length").value = "8";
  document.getElementById("width").value = "8";
  document.getElementById("height").value = "4";
  document.getElementById("color").value = "brown";
  document.getElementById("print").value = "none";
  document.getElementById("coating").value = "none";
  document.getElementById("quantity").value = "500";

  // Display selected images and calculate price
  displaySelectedImages();
  calculatePrice();
});
